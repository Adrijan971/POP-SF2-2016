﻿
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POP_SF02_2016.model
{
    class Global
    {
        public static Global Instance { get; private set; } = new Global();


        public ObservableCollection<Korisnik> Korisnici { get; set; }
        public ObservableCollection<TipNamestaja> TipoviNamestaja { get; set; }
        public ObservableCollection<Namestaj> Namestaj { get; set; }
        public ObservableCollection<DodatnaUsluga> DodatnaUsluga { get; set; }
        public ObservableCollection<ProdajaNamestaja> ProdajaNamestaja { get; set; }
        public ObservableCollection<Akcija> Akcije { get; set; }

        public string ConnectionStr = @"Server=localhost\SQLEXPRESS;Initial Catalog=SalonNamestaja;Trusted_Connection=True;";
        private Global()
        {
            TipoviNamestaja = new ObservableCollection<TipNamestaja>();
            Namestaj = new ObservableCollection<Namestaj>();
            Korisnici = new ObservableCollection<Korisnik>();
            Akcije = new ObservableCollection<Akcija>();
            DodatnaUsluga = new ObservableCollection<DodatnaUsluga>();
            ProdajaNamestaja = new ObservableCollection<ProdajaNamestaja>();
        }

    }
}